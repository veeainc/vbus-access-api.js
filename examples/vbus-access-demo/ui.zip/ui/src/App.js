import React from 'react';
import './App.css';
import {BrowserRouter as Router, Switch, Route} from "react-router-dom";
import Home from "./pages/Home";
import Login from "./pages/Login";
import createApi, {LocalStorage} from "vbus-access-api";
import VeeaContext from "./VeeaContext"


class App extends React.Component {
    state = {
        time: ""
    };

    render() {
        const api = createApi({
            baseUrl: "http://localhost:8080/api/v1/",
            storage: new LocalStorage(),
            onUnauthenticated: (api) => {
                console.log('onUnauthenticated');
                return api.login.post({
                    returnUrl: window.location.href + "login"
                }).then(r => {
                    window.location.replace(r.data.viewUrl)
                }).catch(r => {
                    console.error(r)
                })
            }
        });

        return (
            <div className="App">
                <Router>
                    <VeeaContext.Provider value={api}>
                        <Switch>
                            <Route path="/" exact>
                                <Home/>
                            </Route>
                            <Route path="/login" exact>
                                <Login/>
                            </Route>
                        </Switch>
                    </VeeaContext.Provider>
                </Router>
            </div>
        );
    }
}

export default App;
