import React from "react";

const VeeaContext = React.createContext(null);

export default VeeaContext