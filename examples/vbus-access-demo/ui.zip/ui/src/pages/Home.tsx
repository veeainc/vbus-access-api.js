import React from "react";
import logo from "../logo.svg";
import VeeaContext from "../VeeaContext"
import {AccessApi} from "vbus-access-api";
import { ModuleInfo } from "vbus-access-api/dist/models";

interface State {
    info: ModuleInfo[]
    error: string
}

class Home extends React.Component<{}, State> {
    state = {
        info: [],
        error: ""
    };

    static contextType = VeeaContext;

    componentDidMount() {
        const api: AccessApi = this.context;

        api.services.get().then(r => {
            this.setState({info: r.data})
        }).catch(r => {
            console.error(r.response)
            this.setState({error: r.response.data.message})
        })

        setInterval(() => {

        }, 2000);
    }

    render() {
        const info: ModuleInfo[] = this.state.info;

        return (
            <header className="App-header">
                <img src={logo} className="App-logo" alt="logo"/>
                <a
                    className="App-link"
                    href="https://reactjs.org"
                    target="_blank"
                    rel="noopener noreferrer"
                >
                    Services:
                    <ul>
                        {
                            info.map((inf, i) => <li key={i}>{inf.client} - {inf.hostname} - {inf.id}</li>)
                        }
                    </ul>
                </a>
                <label style={{color: "#ff0000"}}>
                    {this.state.error}
                </label>
            </header>
        );
    }
}

export default Home
