import React from "react";
import {withRouter, RouteComponentProps} from "react-router-dom";
import queryString from 'query-string'
import VeeaContext from "../VeeaContext";
import { AccessApi } from "vbus-access-api";


interface Props extends RouteComponentProps {
}

class Login extends React.Component<Props> {
    static contextType = VeeaContext;

    componentDidMount() {
        const api: AccessApi = this.context;
        const values = queryString.parse(this.props.location.search);

        api.login.finalize.post({
            code: values.code as string,
            state: values.state as string,
        }).then(r => {
            this.props.history.push("/")
        }).catch(r => {
            console.error(r.response)
        });
    }

    render() {
        return (
            <header className="App-header">
                Login page
            </header>
        );
    }
}

export default withRouter(Login)
